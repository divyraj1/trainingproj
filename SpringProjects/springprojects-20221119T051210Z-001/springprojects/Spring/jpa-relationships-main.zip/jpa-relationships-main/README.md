# jpa-relationships
Java Spring Boot project that shows example JPA relationships

# YouTube

Watch the tutorial on YouTube

[![Watch the tutorial on YouTube](https://img.youtube.com/vi/ntN1HWKND8U/maxresdefault.jpg)](https://youtu.be/ntN1HWKND8U)
[![Watch the tutorial on YouTube](https://img.youtube.com/vi/8X1eaC6r2TM/maxresdefault.jpg)](https://youtu.be/8X1eaC6r2TM)
[![Watch the tutorial on YouTube](https://img.youtube.com/vi/QWcIZjg3MQA/maxresdefault.jpg)](https://youtu.be/QWcIZjg3MQA)
[![Watch the tutorial on YouTube](https://img.youtube.com/vi/Svpcn5wJ8CU/maxresdefault.jpg)](https://youtu.be/Svpcn5wJ8CU)
[![Watch the tutorial on YouTube](https://img.youtube.com/vi/tSb02fMEB5o/maxresdefault.jpg)](https://youtu.be/tSb02fMEB5o)
