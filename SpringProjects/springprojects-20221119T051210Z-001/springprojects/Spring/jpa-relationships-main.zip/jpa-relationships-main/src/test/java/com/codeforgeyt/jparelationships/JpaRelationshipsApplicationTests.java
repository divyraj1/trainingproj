package com.codeforgeyt.jparelationships;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaRelationshipsApplicationTests {

	@Test
	void contextLoads() {
	}

}
